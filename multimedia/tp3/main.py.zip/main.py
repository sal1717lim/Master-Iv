import numpy as np
import math
import operator
import collections
import time
import re
from processing_py import *
cos=np.array([ [1  ,  0.98  ,  0.92  ,  0.83  ,  0.7  ,  0.55  ,  0.38  ,  0.19  ],
               [1  ,  0.83  ,  0.38  ,  -0.19 , -0.7  , -0.98  , -0.92  , -0.56  ],
               [1  ,  0.55  , -0.38  ,  -0.98 , -0.7  ,  0.19  ,  0.92  ,  0.83  ],
               [1  ,  0.19  , -0.92  ,  -0.55 ,  0.7  ,  0.83  , -0.38  , -0.98  ],
               [1  , -0.19  , -0.92  ,   0.55 ,  0.7  , -0.83  , -0.38  ,  0.98  ],
               [1  , -0.55  , -0.38  ,   0.98 , -0.7  , -0.19  ,  0.92  , -0.83  ],
               [1  , -0.83  ,  0.38  ,   0.19 , -0.7  ,  0.98  , -0.92  ,  0.56  ],
               [1  , -0.98  ,  0.92  ,  -0.83 ,  0.7  , -0.55  ,  0.38  , -0.19  ] ]  )
app=App(1200,1000)
app.background(153,217,234)
code=""
pos1=300
pos2=500
pos11=10
pos22=20
pos111=500
pos222=20
chaine=""
displaydct=""

class arbre:
    def __init__(self):
        self.val = None
        self.frequence = None
        self.i = 0
        self.j = 0
        self.droite = None
        self.gauche = None

    def printarbre(self):
        if (self != None):
            print(self.val)
            print(self.frequence)
            if (self.droite != None):
                self.droite.printarbre()
            if (self.gauche != None):
                self.gauche.printarbre()


def dessinerarbre(x):
    global pos1
    global pos2
    global code
    global chaine
    global app
    global dicode
    if (x != None):
        if x.droite != None and x.gauche != None:
            time.sleep(0.5)
            app.fill(255)
            tmp=code
            app.ellipse(pos1, pos2, 30, 30)
            app.fill(0)
            app.text(str(x.frequence), pos1, pos2 + 30)
            print(x.val)
            i = pos1
            j = pos2

            pos1 = pos1 - 50
            pos2 = pos2 + 50
            app.stroke(255);
            app.fill(127)
            app.line(i, j, pos1, pos2)
            app.text("0", (i + pos1) / 2, (j + pos2) / 2)
            code = tmp + "0"
            app.redraw()
            dessinerarbre(x.gauche)
            pos1 = pos1 + 100
            app.line(i, j, pos1, pos2)
            app.fill(127)
            l = list(code)
            l[len(l) - 1] = "1"
            code = tmp+'1'
            app.text("1", (i + pos1) / 2, (j + pos2) / 2)
            app.redraw()
            dessinerarbre(x.droite)
        else:
            time.sleep(0.5)
            app.fill(255)
            app.ellipse(pos1, pos2, 30, 30)
            app.fill(0)
            dicode[x.val]=code
            app.text(str(x.val) + ":" + str(x.frequence), pos1-10, pos2 + 30)
            app.redraw



def creerarbre(x):
    y = []
    y.append(x)
    L = list(x.keys())
    x = dict(x)
    z = {}
    i = 400
    j = 20
    tree2 = None
    for i in L:
        tree1 = arbre()
        tree1.val = str(i)
        tree1.frequence = x[i]
        z[str(i)] = tree1

    while len(L) != 1:
        y.append(x)
        x1 = x[L[0]]

        x2 = x[L[1]]
        x[str(L[0]) + str(L[1])] = x1 + x2
        tree2 = arbre()
        tree2.val = str(L[0]) + str(L[1])
        tree2.frequence = x1 + x2
        tree2.droite = z[str(L[0])]
        tree2.gauche = z[str(L[1])]
        print(z)
        z[str(L[0]) + str(L[1])] = tree2
        del x[L[0]]
        del x[L[1]]
        x = trier_dico(x)
        L = list(x.keys())
    return tree2

dct=np.zeros(shape=(8,8))
mq=np.zeros(shape=(8,8))
def alpha(u):
    if(u==0):
        return(1/math.sqrt(2))
    else :
        return 1
def C(img,u,v):
    D=0
    for x in range(0,8):
        for y in range(0,8):
            D=D+img[x][y]*cos[x][u]*cos[y][v]
    return D

def trier_dico(x):
    y=sorted(x.items(), key=operator.itemgetter(1))
    y=collections.OrderedDict(y)

    return dict(y)
def creerdico(x):
    dico={}
    for i in x:
        if(i in dico.keys()):
            dico[i]=dico[i]+1
        else:
            dico[i]=1
    return dico


def calculedct(dct,img):
    global displaydct
    global pos11
    global pos22
    app.textSize(15)
    app.fill(0)
    app.text("calcule de la dct:",pos11,pos22)
    app.redraw()
    for i in range(0,8):
        pos22=pos22+20
        displaydct=""
        for j in range(0,8):
          v=  (2.0/8.0)*C(img,i,j)*alpha(i)*alpha(j)
          dct[i][j]=int(v)
          displaydct=displaydct+ str(dct[i][j])+"   "
          app.text(displaydct,pos11,pos22)
          app.redraw()
    displaydct=""

    return dct.astype(int)

def Matquantification(mq,fq):
    global pos111
    global pos222
    global displaydct
    app.text("matrice de quantification",pos111,pos222)
    app.redraw()
    for i in range(0,8):
        pos222=pos222+20
        displaydct=""
        for j in range(0,8):

            mq[i][j]=1+(1+i+j)*fq
            displaydct=displaydct+str(mq[i][j])+"   "
            app.text(displaydct,pos111,pos222)
            app.redraw()
def huffman(input):
    dico=creerdico(input)
    dico=trier_dico(dico)
    print(dico)
    x=creerarbre(dico)
    return x
def dctquantification(dct,mq):
    return (dct/mq).astype(int)

def parcourzigzag(dctq,n):
    res=[]
    turn=-1
    i=0
    j=0
    for x in range(0,8):
        if turn==1:
            while i<=x:
               # print(dctq[i][j])
                res.append(dctq[i][j])
                i=i+1
                j=j-1


            j=0
        if turn==-1:
            while j<=x:
             #   print(dctq[i][j])
                res.append(dctq[i][j])
                i=i-1
                j=j+1
            i=0
        turn = -turn
    z=1

    i=7
    j=1


    for x in range(7,1,-1):
        if turn==1:
            while i<8:

                res.append(dctq[i][j])
                i=i+1
                j=j-1
            j=j+2
            i=i-1

        if turn==-1:
            while j<8:

                res.append(dctq[i][j])
                i=i-1
                j=j+1
            i=i+2
            j=j-1
        turn = -turn
    res.append(dctq[n-1][n-1])
    return res

def codage(decode,matrice):
    file=open("code.txt","w")
    file2=open('dico.txt',"w")
    for i in matrice:
        for j in i:
            file.write(decode[str(j)]+"\n")
    for i in dicode.items():
        file2.write(i[0]+" : "+i[1]+"\n")

choix=0
while choix!=1 and choix!=2:
    print("vous voulez :\n[1] compresser \n[2] decompresser")
    choix=int(input())

def lecturedico(path):
    file=open(path,"r")
    dico={}

    for x in file.readlines():
        v=re.search("(-?\d*) : (\d*)",x)
        dico[v.group(2)]=int(v.group(1))
    return dico
def reversezigzag(dico,path):
    file = open(path, "r")
    mat=np.zeros((8,8))

    for i in range(0, 8):
        for j in range (0,8):
                # print(dctq[i][j])
                v=file.readline()
                v=v.split("\n")[0]
                mat[i][j]=dico[v]

    return mat
def restoreimage(mat):
    img=np.zeros((8,8))
    for u in range(8):
        for v in range(8):
            img[u][v]=int((2/8)*dcti(mat,u,v))
    return img
def dcti(mat,u,v):
    d=0
    global cos
    for i in range(8):
        for j in range(8):
            print(cos[v][j])
            d=d+mat[i][j]*cos[v][i]*cos[u][j]*alpha(u)*alpha(v)
    return d

if choix==1:

    print("donner le nom de votre image")
    image = input()
    print("donner le facteur de qualité")
    fq = int(input())
    img=np.loadtxt(image)
    dct=calculedct(dct,img)
    Matquantification(mq,fq)
    Q=dctquantification(dct,mq)
    l=parcourzigzag(Q,8)
    pos2=pos22+50
    arbre=huffman(l)
    dessinerarbre(arbre)
    app.redraw()
    pos1=20
    pos2=pos2+50
    codage(dicode,Q)
    app.text("fichier code.txt et fichier dico.txt save",pos1,pos2)
    app.redraw()
if choix==2:
    dico =lecturedico("dico.txt")
    mat=reversezigzag(dico,"code.txt")
    print("donner le facteur de qualité")
    fq = int(input())
    Matquantification(mq,fq)
    mat=mat*mq
    print(mat)
    print(restoreimage(mat))
